// ========== POST CREATION ==========
let selectedPostType = 'image';
let pendingMedia = null;
let selectedMusic = null;

document.getElementById('createPostBtn')?.addEventListener('click', () => {
    document.getElementById('postModal').classList.add('open');
});

document.querySelectorAll('.post-type-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.post-type-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        selectedPostType = btn.dataset.type;
        document.getElementById('musicSelector').style.display = selectedPostType === 'video' ? 'block' : 'none';
    });
});

document.getElementById('uploadZone')?.addEventListener('click', () => {
    document.getElementById('fileInput').click();
});

document.getElementById('fileInput')?.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    pendingMedia = file;
    document.getElementById('uploadZone').innerHTML = file.type.startsWith('image') ? '✅ Image selected' : '✅ Video selected';
});

document.getElementById('publishPostBtn')?.addEventListener('click', async () => {
    if (!pendingMedia) {
        showToast('Please select an image or video');
        return;
    }
    
    const formData = new FormData();
    formData.append('media', pendingMedia);
    formData.append('caption', document.getElementById('captionInput').value);
    if (selectedMusic) {
        formData.append('music', selectedMusic.name);
        formData.append('musicId', selectedMusic.id);
    }
    
    try {
        const res = await fetch(`${API_URL}/api/posts`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${authToken}` },
            body: formData
        });
        if (res.ok) {
            showToast('✅ Post shared!');
            document.getElementById('postModal').classList.remove('open');
            document.getElementById('captionInput').value = '';
            pendingMedia = null;
            document.getElementById('uploadZone').innerHTML = '📸 Tap to select';
            if (typeof loadFeed === 'function') loadFeed();
        }
    } catch (err) {
        showToast('Error posting');
    }
});

// Music search
document.getElementById('musicSearch')?.addEventListener('input', async (e) => {
    const query = e.target.value;
    if (query.length < 2) return;
    
    try {
        const res = await fetch(`${API_URL}/api/music/search?q=${encodeURIComponent(query)}`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        const tracks = await res.json();
        const resultsDiv = document.getElementById('musicResults');
        resultsDiv.innerHTML = tracks.map(track => `
            <div class="music-item" onclick="selectMusic('${track.id}', '${track.name} - ${track.artists}')">
                <img src="${track.albumImage}" onerror="this.src='/default-album.png'">
                <div class="music-info">
                    <div class="music-name">${track.name}</div>
                    <div class="music-artist">${track.artists}</div>
                </div>
            </div>
        `).join('');
    } catch (err) {}
});

window.selectMusic = (id, name) => {
    selectedMusic = { id, name };
    document.getElementById('musicSearch').value = name;
    document.getElementById('musicResults').innerHTML = '';
    showToast(`🎵 Music added: ${name}`);
};