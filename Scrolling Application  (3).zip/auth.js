// ========== AUTHENTICATION ==========
let currentUser = null;
let authToken = localStorage.getItem('token');

function showToast(msg) {
    let toast = document.getElementById('toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'toast';
        toast.className = 'toast';
        document.body.appendChild(toast);
    }
    toast.innerText = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2500);
}

async function register(username, email, password) {
    try {
        const res = await fetch(`${API_URL}/api/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password })
        });
        const data = await res.json();
        if (res.ok) {
            authToken = data.token;
            localStorage.setItem('token', authToken);
            currentUser = data.user;
            showToast('✅ Account created!');
            return true;
        } else {
            showToast(data.error || 'Registration failed');
            return false;
        }
    } catch {
        showToast('Network error');
        return false;
    }
}

async function login(username, password) {
    try {
        const res = await fetch(`${API_URL}/api/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await res.json();
        if (res.ok) {
            authToken = data.token;
            localStorage.setItem('token', authToken);
            currentUser = data.user;
            showToast('✅ Login successful!');
            return true;
        } else {
            showToast(data.error || 'Login failed');
            return false;
        }
    } catch {
        showToast('Network error');
        return false;
    }
}

function logout() {
    localStorage.removeItem('token');
    authToken = null;
    currentUser = null;
    window.location.href = '/login.html';
}

// Handle login page
if (document.getElementById('loginBtn')) {
    let isSignup = false;
    
    document.getElementById('loginBtn').onclick = async () => {
        const username = document.getElementById('loginUsername').value.trim();
        const email = document.getElementById('loginEmail').value.trim();
        const password = document.getElementById('loginPassword').value;
        
        if (!username || !email || !password) {
            showToast('All fields required');
            return;
        }
        
        let success = isSignup ? await register(username, email, password) : await login(username, password);
        if (success) window.location.href = '/';
    };
    
    document.getElementById('toggleAuth').onclick = () => {
        isSignup = !isSignup;
        document.getElementById('loginBtn').innerText = isSignup ? 'Sign Up' : 'Login';
        document.getElementById('toggleAuth').innerHTML = isSignup ? 
            '<span>🔐 Already have an account? Login</span>' : 
            '<span>➕ Create New Account</span>';
    };
    
    document.getElementById('googleBtn').onclick = () => showToast('Google login coming soon!');
    
    if (document.getElementById('languageSelect')) {
        document.getElementById('languageSelect').value = currentLanguage;
        document.getElementById('languageSelect').onchange = (e) => setLanguage(e.target.value);
    }
}

// Check auth for protected pages
if (!window.location.pathname.includes('login.html')) {
    if (!authToken) {
        window.location.href = '/login.html';
    } else {
        fetch(`${API_URL}/api/users/me`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        }).then(res => res.json()).then(data => {
            if (!data.id) window.location.href = '/login.html';
            else currentUser = data;
        }).catch(() => window.location.href = '/login.html');
    }
}