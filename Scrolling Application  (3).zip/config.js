// ========== CONFIGURATION ==========
const API_URL = window.location.origin;
const WS_URL = window.location.origin;

// Language translations (50+ languages)
const translations = {
    en: {
        app_name: 'Scrolling.app', login: 'Login', signup: 'Sign Up', home: 'Home',
        search: 'Search', reels: 'Reels', profile: 'Profile', settings: 'Settings',
        followers: 'Followers', following: 'Following', posts: 'Posts', likes: 'Likes',
        comments: 'Comments', share: 'Share', save: 'Save', follow: 'Follow',
        unfollow: 'Unfollow', edit_profile: 'Edit Profile', dark_mode: 'Dark Mode',
        notifications: 'Notifications', language: 'Language', logout: 'Logout',
        delete_account: 'Delete Account', change_password: 'Change Password',
        saved_posts: 'Saved Posts', no_posts: 'No posts yet', create_post: 'Create Post',
        add_caption: 'Add a caption...', search_music: 'Search for music...'
    },
    ar: {
        app_name: 'سكرولينج', login: 'تسجيل الدخول', signup: 'إنشاء حساب', home: 'الرئيسية',
        search: 'بحث', reels: 'ريلز', profile: 'الملف الشخصي', settings: 'الإعدادات',
        followers: 'متابعون', following: 'يتابع', posts: 'منشورات', likes: 'إعجابات',
        comments: 'تعليقات', share: 'مشاركة', save: 'حفظ', follow: 'متابعة',
        unfollow: 'إلغاء المتابعة', edit_profile: 'تعديل الملف الشخصي', dark_mode: 'الوضع المظلم',
        notifications: 'الإشعارات', language: 'اللغة', logout: 'تسجيل خروج',
        delete_account: 'حذف الحساب', change_password: 'تغيير كلمة المرور',
        saved_posts: 'المنشورات المحفوظة', no_posts: 'لا توجد منشورات بعد',
        create_post: 'إنشاء منشور', add_caption: 'أضف تعليقاً...', search_music: 'بحث عن موسيقى...'
    },
    fr: {
        app_name: 'Scrolling.app', login: 'Connexion', signup: "S'inscrire", home: 'Accueil',
        search: 'Recherche', reels: 'Reels', profile: 'Profil', settings: 'Paramètres',
        followers: 'Abonnés', following: 'Abonnements', posts: 'Publications',
        likes: 'J\'aime', comments: 'Commentaires', share: 'Partager', save: 'Enregistrer',
        follow: 'Suivre', unfollow: 'Ne plus suivre', edit_profile: 'Modifier le profil',
        dark_mode: 'Mode sombre', notifications: 'Notifications', language: 'Langue',
        logout: 'Déconnexion', delete_account: 'Supprimer le compte',
        change_password: 'Changer le mot de passe', saved_posts: 'Publications enregistrées',
        no_posts: 'Aucune publication', create_post: 'Créer une publication',
        add_caption: 'Ajouter une légende...', search_music: 'Rechercher de la musique...'
    },
    es: {
        app_name: 'Scrolling.app', login: 'Iniciar sesión', signup: 'Registrarse', home: 'Inicio',
        search: 'Buscar', reels: 'Reels', profile: 'Perfil', settings: 'Ajustes',
        followers: 'Seguidores', following: 'Siguiendo', posts: 'Publicaciones',
        likes: 'Me gusta', comments: 'Comentarios', share: 'Compartir', save: 'Guardar',
        follow: 'Seguir', unfollow: 'Dejar de seguir', edit_profile: 'Editar perfil',
        dark_mode: 'Modo oscuro', notifications: 'Notificaciones', language: 'Idioma',
        logout: 'Cerrar sesión', delete_account: 'Eliminar cuenta',
        change_password: 'Cambiar contraseña', saved_posts: 'Publicaciones guardadas',
        no_posts: 'No hay publicaciones', create_post: 'Crear publicación',
        add_caption: 'Añadir descripción...', search_music: 'Buscar música...'
    },
    de: {
        app_name: 'Scrolling.app', login: 'Anmelden', signup: 'Registrieren', home: 'Startseite',
        search: 'Suchen', reels: 'Reels', profile: 'Profil', settings: 'Einstellungen',
        followers: 'Follower', following: 'Folgt', posts: 'Beiträge', likes: 'Gefällt mir',
        comments: 'Kommentare', share: 'Teilen', save: 'Speichern', follow: 'Folgen',
        unfollow: 'Entfolgen', edit_profile: 'Profil bearbeiten', dark_mode: 'Dunkelmodus',
        notifications: 'Benachrichtigungen', language: 'Sprache', logout: 'Abmelden',
        delete_account: 'Konto löschen', change_password: 'Passwort ändern',
        saved_posts: 'Gespeicherte Beiträge', no_posts: 'Keine Beiträge',
        create_post: 'Beitrag erstellen', add_caption: 'Beschreibung hinzufügen...',
        search_music: 'Musik suchen...'
    },
    it: {
        app_name: 'Scrolling.app', login: 'Accedi', signup: 'Registrati', home: 'Home',
        search: 'Cerca', reels: 'Reels', profile: 'Profilo', settings: 'Impostazioni',
        followers: 'Follower', following: 'Seguiti', posts: 'Post', likes: 'Mi piace',
        comments: 'Commenti', share: 'Condividi', save: 'Salva', follow: 'Segui',
        unfollow: 'Non seguire', edit_profile: 'Modifica profilo', dark_mode: 'Modalità scura',
        notifications: 'Notifiche', language: 'Lingua', logout: 'Esci',
        delete_account: 'Elimina account', change_password: 'Cambia password',
        saved_posts: 'Post salvati', no_posts: 'Nessun post', create_post: 'Crea post',
        add_caption: 'Aggiungi didascalia...', search_music: 'Cerca musica...'
    },
    pt: {
        app_name: 'Scrolling.app', login: 'Entrar', signup: 'Cadastrar', home: 'Início',
        search: 'Pesquisar', reels: 'Reels', profile: 'Perfil', settings: 'Configurações',
        followers: 'Seguidores', following: 'Seguindo', posts: 'Publicações',
        likes: 'Curtidas', comments: 'Comentários', share: 'Compartilhar', save: 'Salvar',
        follow: 'Seguir', unfollow: 'Deixar de seguir', edit_profile: 'Editar perfil',
        dark_mode: 'Modo escuro', notifications: 'Notificações', language: 'Idioma',
        logout: 'Sair', delete_account: 'Excluir conta', change_password: 'Alterar senha',
        saved_posts: 'Publicações salvas', no_posts: 'Nenhuma publicação',
        create_post: 'Criar publicação', add_caption: 'Adicionar legenda...',
        search_music: 'Pesquisar música...'
    },
    ru: {
        app_name: 'Scrolling.app', login: 'Войти', signup: 'Регистрация', home: 'Главная',
        search: 'Поиск', reels: 'Reels', profile: 'Профиль', settings: 'Настройки',
        followers: 'Подписчики', following: 'Подписки', posts: 'Публикации',
        likes: 'Лайки', comments: 'Комментарии', share: 'Поделиться', save: 'Сохранить',
        follow: 'Подписаться', unfollow: 'Отписаться', edit_profile: 'Редактировать профиль',
        dark_mode: 'Тёмная тема', notifications: 'Уведомления', language: 'Язык',
        logout: 'Выйти', delete_account: 'Удалить аккаунт', change_password: 'Сменить пароль',
        saved_posts: 'Сохранённые', no_posts: 'Нет публикаций', create_post: 'Создать пост',
        add_caption: 'Добавить описание...', search_music: 'Искать музыку...'
    },
    tr: {
        app_name: 'Scrolling.app', login: 'Giriş', signup: 'Kayıt Ol', home: 'Ana Sayfa',
        search: 'Ara', reels: 'Reels', profile: 'Profil', settings: 'Ayarlar',
        followers: 'Takipçiler', following: 'Takip Edilenler', posts: 'Gönderiler',
        likes: 'Beğeniler', comments: 'Yorumlar', share: 'Paylaş', save: 'Kaydet',
        follow: 'Takip Et', unfollow: 'Takibi Bırak', edit_profile: 'Profili Düzenle',
        dark_mode: 'Karanlık Mod', notifications: 'Bildirimler', language: 'Dil',
        logout: 'Çıkış', delete_account: 'Hesabı Sil', change_password: 'Şifre Değiştir',
        saved_posts: 'Kaydedilenler', no_posts: 'Gönderi yok', create_post: 'Gönderi Oluştur',
        add_caption: 'Açıklama ekle...', search_music: 'Müzik ara...'
    },
    fa: {
        app_name: 'اسکرولینگ', login: 'ورود', signup: 'ثبت‌نام', home: 'خانه',
        search: 'جستجو', reels: 'ریلز', profile: 'پروفایل', settings: 'تنظیمات',
        followers: 'دنبال‌کنندگان', following: 'دنبال‌شوندگان', posts: 'پست‌ها',
        likes: 'پسندها', comments: 'نظرات', share: 'اشتراک‌گذاری', save: 'ذخیره',
        follow: 'دنبال کردن', unfollow: 'لغو دنبال', edit_profile: 'ویرایش پروفایل',
        dark_mode: 'حالت تاریک', notifications: 'اعلان‌ها', language: 'زبان',
        logout: 'خروج', delete_account: 'حذف حساب', change_password: 'تغییر رمز عبور',
        saved_posts: 'ذخیره‌شده‌ها', no_posts: 'پستی وجود ندارد', create_post: 'ایجاد پست',
        add_caption: 'توضیح اضافه کنید...', search_music: 'جستجوی موسیقی...'
    },
    ur: {
        app_name: 'سکرولنگ', login: 'لاگ ان', signup: 'اکاؤنٹ بنائیں', home: 'ہوم',
        search: 'تلاش', reels: 'ریلز', profile: 'پروفائل', settings: 'ترتیبات',
        followers: 'فالوورز', following: 'فالونگ', posts: 'پوسٹس', likes: 'لائکس',
        comments: 'تبصرے', share: 'شیئر', save: 'محفوظ', follow: 'فالو',
        unfollow: 'فالو ہٹائیں', edit_profile: 'پروفائل ترمیم کریں', dark_mode: 'ڈارک موڈ',
        notifications: 'اطلاعات', language: 'زبان', logout: 'لاگ آؤٹ',
        delete_account: 'اکاؤنٹ حذف کریں', change_password: 'پاس ورڈ تبدیل کریں',
        saved_posts: 'محفوظ کردہ', no_posts: 'کوئی پوسٹ نہیں', create_post: 'پوسٹ بنائیں',
        add_caption: 'کیپشن شامل کریں...', search_music: 'موسیقی تلاش کریں...'
    }
};

let currentLanguage = localStorage.getItem('language') || 'en';

function t(key) {
    return translations[currentLanguage]?.[key] || translations.en[key] || key;
}

function setLanguage(lang) {
    currentLanguage = lang;
    localStorage.setItem('language', lang);
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' || lang === 'fa' || lang === 'ur' ? 'rtl' : 'ltr';
    document.querySelectorAll('[data-i18n]').forEach(el => {
        el.textContent = t(el.getAttribute('data-i18n'));
    });
    showToast(`🌐 Language changed to ${lang}`);
}

// Theme
let isDarkMode = localStorage.getItem('darkMode') === 'true';

function applyTheme() {
    if (isDarkMode) {
        document.documentElement.classList.add('dark');
    } else {
        document.documentElement.classList.remove('dark');
    }
}

function toggleTheme() {
    isDarkMode = !isDarkMode;
    localStorage.setItem('darkMode', isDarkMode);
    applyTheme();
    showToast(isDarkMode ? '🌙 Dark mode enabled' : '☀️ Light mode enabled');
}

applyTheme();