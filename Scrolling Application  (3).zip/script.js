// ========== TOAST ==========
function showToast(msg) {
    let toast = document.getElementById('toast');
    if (!toast) { toast = document.createElement('div'); toast.id = 'toast'; toast.className = 'toast'; document.body.appendChild(toast); }
    toast.innerText = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2500);
}

// ========== AUTH ==========
let currentUser = localStorage.getItem('currentUser');
let users = JSON.parse(localStorage.getItem('users') || '{}');

if (Object.keys(users).length === 0) {
    users['test'] = { password: '123', email: 'test@test.com', name: 'Test User', avatar: '👤', bio: '✨ Welcome! ✨', followers: 0, following: 0 };
    users['jorge'] = { password: '123', email: 'jorge@test.com', name: 'Jorge', avatar: '👤', bio: '✨ Welcome! ✨', followers: 0, following: 0 };
    localStorage.setItem('users', JSON.stringify(users));
}

// Login page
if (document.getElementById('loginBtn')) {
    let isSignup = false;
    document.getElementById('loginBtn').onclick = () => {
        const u = document.getElementById('loginUsername').value.trim();
        const e = document.getElementById('loginEmail').value.trim();
        const p = document.getElementById('loginPassword').value;
        if (!u || !e || !p) { showToast('All fields required'); return; }
        if (isSignup) {
            if (users[u]) { showToast('Username exists'); return; }
            users[u] = { password: p, email: e, name: u, avatar: '👤', bio: '✨ Welcome! ✨', followers: 0, following: 0 };
            localStorage.setItem('users', JSON.stringify(users));
            localStorage.setItem('currentUser', u);
            showToast('✅ Account created!');
            window.location.href = '/index.html';
        } else {
            if (users[u] && users[u].password === p) {
                localStorage.setItem('currentUser', u);
                showToast('✅ Login successful!');
                window.location.href = '/index.html';
            } else { showToast('❌ Invalid credentials'); }
        }
    };
    document.getElementById('toggleAuth').onclick = () => {
        isSignup = !isSignup;
        document.getElementById('loginBtn').innerText = isSignup ? 'Sign Up' : 'Login';
        document.getElementById('toggleAuth').innerHTML = isSignup ? '<span>🔐 Login</span>' : '<span>➕ Create Account</span>';
    };
    document.getElementById('googleBtn').onclick = () => showToast('Google login coming soon');
}

// ========== FEED ==========
let posts = JSON.parse(localStorage.getItem('posts') || '[]');
let stories = JSON.parse(localStorage.getItem('stories') || '[]');

function loadFeed() {
    const container = document.getElementById('feedList');
    if (!container) return;
    if (posts.length === 0) { container.innerHTML = '<div class="empty-state">✨ No posts yet. Tap + to create!</div>'; return; }
    container.innerHTML = posts.slice().reverse().map(p => `
        <div class="post">
            <div class="post-header"><div class="post-user"><div class="post-avatar">${users[p.username]?.avatar || '👤'}</div><div><strong>${p.username}</strong></div></div><span>⋯</span></div>
            <div class="post-media" onclick="window.open('${p.media}','_blank')">${p.type === 'image' ? `<img src="${p.media}">` : `<video src="${p.media}" controls></video>`}</div>
            <div class="post-actions"><div class="action-group"><button class="action-btn" onclick="likePost('${p.id}')">❤️ ${p.likes || 0}</button><button class="action-btn">💬 ${p.comments?.length || 0}</button><button class="action-btn">🔖</button></div><button class="action-btn">📤</button></div>
            <div class="likes-count">${p.likes || 0} likes</div><div class="post-caption"><strong>${p.username}</strong> ${p.caption || ''}</div>
        </div>
    `).join('');
}

function likePost(id) { let p = posts.find(p => p.id == id); if(p){ p.likes = (p.likes || 0) + 1; localStorage.setItem('posts', JSON.stringify(posts)); loadFeed(); showToast('❤️ Liked!'); } }

// ========== STORIES ==========
function loadStories() {
    const container = document.getElementById('storiesList');
    if (!container) return;
    let myStory = `<div class="story-item" onclick="openStoryUpload()"><div class="story-ring"><div class="story-avatar">+</div></div><span class="story-name">Your Story</span></div>`;
    let other = stories.filter(s => s.username !== currentUser).slice(0,10).map(s => `<div class="story-item" onclick="viewStory('${s.media}')"><div class="story-ring"><div class="story-avatar">📷</div></div><span class="story-name">${s.username.substring(0,8)}</span></div>`).join('');
    container.innerHTML = myStory + other;
}

function openStoryUpload() { let input = document.createElement('input'); input.type = 'file'; input.accept = 'image/*,video/*'; input.onchange = e => { let f = e.target.files[0]; if(!f) return; let r = new FileReader(); r.onload = ev => { stories.unshift({ id: Date.now(), username: currentUser, media: ev.target.result, type: f.type.startsWith('image')?'image':'video', timestamp: Date.now() }); localStorage.setItem('stories', JSON.stringify(stories)); loadStories(); showToast('📖 Story added!'); }; r.readAsDataURL(f); }; input.click(); }
function viewStory(src) { window.open(src, '_blank'); }

// ========== REELS ==========
function loadReels() {
    const container = document.getElementById('reelsContainer');
    if (!container) return;
    let reels = posts.filter(p => p.type === 'video').slice().reverse();
    if (reels.length === 0) { container.innerHTML = '<div class="empty-state" style="color:white;background:black;height:100%;display:flex;align-items:center;justify-content:center;">🎬 No reels yet. Upload a video!</div>'; return; }
    container.innerHTML = reels.map(r => `
        <div class="reel-item"><video class="reel-video" src="${r.media}" loop autoplay muted playsinline></video>
        <div class="reel-overlay"><div><strong>@${r.username}</strong></div><div>${r.caption || ''}</div></div>
        <div class="reel-actions"><button class="reel-action" onclick="likeReel('${r.id}')">❤️ <span>${r.likes || 0}</span></button><button class="reel-action" onclick="sharePost('${r.id}')">📤</button></div></div>
    `).join('');
}
function likeReel(id) { let p = posts.find(p => p.id == id); if(p){ p.likes = (p.likes || 0) + 1; localStorage.setItem('posts', JSON.stringify(posts)); loadReels(); showToast('❤️ Liked!'); } }
function sharePost(id) { showToast('✨ Shared!'); }

// ========== PROFILE ==========
function loadProfile() {
    let u = users[currentUser] || { name: currentUser, avatar: '👤', bio: '✨ Welcome! ✨', followers: 0, following: 0 };
    let userPosts = posts.filter(p => p.username === currentUser);
    document.getElementById('profileName').innerText = u.name;
    document.getElementById('profileBio').innerText = u.bio;
    document.getElementById('postCount').innerText = userPosts.length;
    document.getElementById('followerCount').innerText = u.followers || 0;
    document.getElementById('followingCount').innerText = u.following || 0;
    let grid = document.getElementById('profileGrid');
    if (userPosts.length === 0) grid.innerHTML = '<div class="empty-state">📭 No posts yet</div>';
    else grid.innerHTML = userPosts.map(p => `<div class="grid-item" onclick="window.open('${p.media}','_blank')">${p.type === 'image' ? `<img src="${p.media}">` : `<video src="${p.media}"></video>`}</div>`).join('');
}

function editProfile() {
    let u = users[currentUser] || {};
    document.getElementById('editName').value = u.name || '';
    document.getElementById('editBio').value = u.bio || '';
    document.getElementById('editAvatar').value = u.avatar || '👤';
    document.getElementById('editProfileModal').classList.add('open');
}
function closeEditModal() { document.getElementById('editProfileModal').classList.remove('open'); }
function saveProfile() {
    users[currentUser] = { ...users[currentUser], name: document.getElementById('editName').value || currentUser, bio: document.getElementById('editBio').value || '✨ Welcome! ✨', avatar: document.getElementById('editAvatar').value || '👤' };
    localStorage.setItem('users', JSON.stringify(users));
    closeEditModal();
    loadProfile();
    showToast('✅ Profile updated!');
}

// ========== SETTINGS ==========
function logout() { localStorage.removeItem('currentUser'); window.location.href = '/login.html'; }
function changePassword() { let np = prompt('New password:'); if(np && np.length>=3){ users[currentUser].password = np; localStorage.setItem('users', JSON.stringify(users)); showToast('Password changed'); } }
function deleteAccount() { if(confirm('Delete account?')){ delete users[currentUser]; posts = posts.filter(p => p.username !== currentUser); localStorage.setItem('users', JSON.stringify(users)); localStorage.setItem('posts', JSON.stringify(posts)); logout(); } }

// ========== CREATE POST ==========
let pendingMedia = null, pendingType = 'image';
function openCreatePost() { document.getElementById('postModal').classList.add('open'); }
function closeModal() { document.getElementById('postModal').classList.remove('open'); pendingMedia = null; document.getElementById('uploadZone').innerHTML = '📸 Tap to select'; }
document.querySelectorAll('.post-type-btn')?.forEach(btn => { btn.onclick = () => { document.querySelectorAll('.post-type-btn').forEach(b => b.classList.remove('active')); btn.classList.add('active'); pendingType = btn.dataset.type; document.getElementById('uploadZone').innerHTML = pendingType === 'image' ? '📸 Tap to select image' : '🎬 Tap to select video'; document.getElementById('fileInput').accept = pendingType === 'image' ? 'image/*' : 'video/*'; }; });
document.getElementById('uploadZone')?.addEventListener('click', () => document.getElementById('fileInput').click());
document.getElementById('fileInput')?.addEventListener('change', (e) => { let f = e.target.files[0]; if(!f) return; let r = new FileReader(); r.onload = ev => { pendingMedia = ev.target.result; document.getElementById('uploadZone').innerHTML = pendingType === 'image' ? '✅ Image selected' : '✅ Video selected'; }; r.readAsDataURL(f); });
document.getElementById('publishPostBtn')?.addEventListener('click', () => { if(!pendingMedia){ showToast('Select media'); return; } let newPost = { id: Date.now(), username: currentUser, media: pendingMedia, type: pendingType, caption: document.getElementById('captionInput').value, likes: 0, comments: [] }; posts.unshift(newPost); localStorage.setItem('posts', JSON.stringify(posts)); closeModal(); document.getElementById('captionInput').value = ''; if(document.getElementById('feedList')) loadFeed(); if(document.getElementById('reelsContainer')) loadReels(); if(document.getElementById('profileGrid')) loadProfile(); showToast('✅ Post shared!'); });

// Initialize pages
if (document.getElementById('feedList')) { loadFeed(); loadStories(); }
if (document.getElementById('reelsContainer')) { loadReels(); }
if (document.getElementById('profileName')) { loadProfile(); }